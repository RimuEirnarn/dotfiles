#!/bin/bash

suexec=""

if [ ! $UID = 0 ]; then
    suexec="sudo"
fi

IMG_DIR="$1"

if [ "$IMG_DIR" = "" ]; then
    echo "Where's container name?"
    exit 1
fi

$suexec bin/pivot_exec "$IMG_DIR" /usr/sbin/init-container
