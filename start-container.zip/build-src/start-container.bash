#!/bin/bash

suexec=""

if [ ! $UID = 0 ]; then
    suexec="sudo"
fi

$suexec bin/pivot_exec "$1" /usr/sbin/init-container
