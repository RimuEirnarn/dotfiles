#!/usr/bin/bash

printf "Initiating\n"

printf "Configuring...\n"

mount -t devtmpfs none /dev
mount -t proc proc /proc
mount -t sysfs none /sys
mount -t devpts none /dev/pts -o newinstance,gid=5,mode=620,ptmxmode=000,nosuid,noexec,relatime

hostname rimueirnarn

printf "Executing...\n"
bash -l
printf "Done.\n"
