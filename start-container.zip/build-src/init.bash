#!/usr/bin/bash

handler(){
    printf "Container finalizing... attempted to tell child to gracefully close for 3 seconds.\n"

    pkill -P $$

    sleep 3

    printf "attempted to kill every stubborn child right away.\n"

    pkill -P $$ --signal 9

    exit 0
}

trap handler SIGINT SIGTERM

mount -t devtmpfs none /dev
mount -t proc proc /proc
mount -t sysfs none /sys
mount -t devpts none /dev/pts -o newinstance,gid=5,mode=620,ptmxmode=000,nosuid,noexec,relatime

hostname rimueirnarn

/etc/rimueirnarn.d/init/*

printf "Press Enter enter bash, CTRL+C to stop.\n"


while [ true ]; do
    read
    bash
done

handler
